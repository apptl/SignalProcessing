#Arpan Patel
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg 


#array of .1s to convolve

array = [.1,.1,.1,.1,.1,.1,.1,.1,.1,.1]

#convolving each picture with lowpass
#each pics row is convolved with .1s array
plt.figure()
img = mpimg.imread("clock-5.1.12.tiff") 
img2 = []
for i in img:
    img2.append(np.convolve(i,array))
    
plt.imshow(img2,cmap='Greys_r') 
plt.title("clock")

plt.figure()
img = mpimg.imread("boat.512.tiff") 
img2 = []
for i in img:
    img2.append(np.convolve(i,array))
    
plt.imshow(img2,cmap='Greys_r') 
plt.title("boat")

plt.figure()
img = mpimg.imread("man-5.3.01.tiff") 
img2 = []
for i in img:
    img2.append(np.convolve(i,array))
    
plt.imshow(img2,cmap='Greys_r') 
plt.title("man")

plt.figure()
img = mpimg.imread("tank-7.1.07.tiff") 
img2 = []
for i in img:
    img2.append(np.convolve(i,array))
    
plt.imshow(img2,cmap='Greys_r') 
plt.title("boat")


